<html>
<head>
<link type="text/css" href="css/droppy.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/jquery.droppy.js"></script>
<script language="javascript">
$(function()
	{
	$('#nav').droppy({speed: 100});
	});
</script>
</head>
<body>
<?
function geraMenuAuto($id = 0)
	{
	$sql = "SELECT * FROM menu WHERE id_menu_pai = '" . $id . "' ORDER BY id_menu";
	$conexao = mysql_connect("localhost", "root", ""); //MODIFIQUE ESTA LINHA COM OS DADOS DO SEU SERVIDOR
	$bd = mysql_select_db("edit", $conexao); //MODIFIQUE ESTA LINHA COM O NOME DO SEU BANCO DE DADOS
	$query = mysql_query($sql);
	mysql_close($conexao);
	$numLinhas = mysql_num_rows($query);
	for($i = 0; $i < $numLinhas; $i++)
		{
		list($id_menu, $id_menu_pai, $titulo, $link) = mysql_fetch_row($query);
		if (existeFilho($id_menu) > 0)
			{
			$var .= "	<li>$titulo\n";
			$var .= "		<ul>\n" . geraMenuAuto($id_menu) . "    </ul>\n";
			$var .= "	</li>\n";
			}
		else
			$var .= "	<li><a href=\"$link\">$titulo</a></li>\n";
		}
	if (strlen($var) > 0)
		return $var;
	else
		return false;
	}
function existeFilho($id)
	{
	$sql = "SELECT * FROM menu WHERE id_menu_pai = '" . $id . "' ORDER BY id_menu_pai";
	$conexao = mysql_connect("localhost", "root", ""); //MODIFIQUE ESTA LINHA COM OS DADOS DO SEU SERVIDOR
	$bd = mysql_select_db("edit", $conexao); //MODIFIQUE ESTA LINHA COM O NOME DO SEU BANCO DE DADOS
	$query = mysql_query($sql);
	mysql_close($conexao);
	return mysql_num_rows($query);
	}
?>
<ul id="nav">
<?
echo geraMenuAuto();
?>
</ul>